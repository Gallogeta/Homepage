#pragma once

char *do_open_rom_dialog(void);
char *do_open_folder_dialog(void);
char *do_save_recording_dialog(unsigned frequency);
