#include_next <limits.h>
#define PATH_MAX 1024
