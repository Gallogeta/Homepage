#ifndef _WIN32
#error windows_associations.h included while building for a different platform
#endif
#include <stdbool.h>
bool GB_do_windows_association(void);
