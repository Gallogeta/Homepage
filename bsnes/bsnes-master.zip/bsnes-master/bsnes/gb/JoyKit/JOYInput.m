#import "JOYInput.h"

@interface JOYInput ()
@property unsigned combinedIndex;
@end

@implementation JOYInput

- (uint64_t)uniqueID
{
    [self doesNotRecognizeSelector:_cmd];
    __builtin_unreachable();
}

- (NSString *)usageString
{
    [self doesNotRecognizeSelector:_cmd];
    __builtin_unreachable();
}

@end
