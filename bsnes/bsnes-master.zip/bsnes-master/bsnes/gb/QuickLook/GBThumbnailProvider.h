#import <QuickLookThumbnailing/QuickLookThumbnailing.h>

API_AVAILABLE(macos(10.15))
@interface GBThumbnailProvider : QLThumbnailProvider
@end
