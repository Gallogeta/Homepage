#import <Cocoa/Cocoa.h>
#import <Quartz/Quartz.h>

API_AVAILABLE(macos(12.0))
@interface GBPreviewProvider : QLPreviewProvider <QLPreviewingController>
@end
