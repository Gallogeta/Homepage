#import <Cocoa/Cocoa.h>

@interface GBCPUView : NSView
- (void)addSample:(double)sample;
@end
