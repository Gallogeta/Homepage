#import <Cocoa/Cocoa.h>

@interface GBColorTextCell : NSTextFieldCell

@end
