#import <Cocoa/Cocoa.h>

@interface GBBorderView : NSView

@end
