#import <Cocoa/Cocoa.h>

@interface GBPanel : NSPanel
@property (weak) IBOutlet NSWindow *ownerWindow;
@end
