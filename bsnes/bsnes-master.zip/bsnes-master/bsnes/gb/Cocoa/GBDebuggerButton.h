#import <Cocoa/Cocoa.h>

@class GBDocument;
@interface GBDebuggerButton : NSButton
@property (weak) IBOutlet NSTextField *textField;
@end

