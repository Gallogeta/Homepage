#import <Cocoa/Cocoa.h>

@interface GBToolbarFieldCell : NSSearchFieldCell

@end
