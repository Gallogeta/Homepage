#import <Cocoa/Cocoa.h>

@interface GBWindow : NSWindow

@end
