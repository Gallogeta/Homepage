#import <Cocoa/Cocoa.h>

@interface GBCenteredTextCell : NSTextFieldCell

@end
