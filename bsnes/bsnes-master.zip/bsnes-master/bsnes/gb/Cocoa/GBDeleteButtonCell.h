#import <Cocoa/Cocoa.h>

@interface GBDeleteButtonCell : NSButtonCell

@end
