#import <Cocoa/Cocoa.h>

@interface GBDisabledButton : NSButton

@end
