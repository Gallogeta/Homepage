#import <Cocoa/Cocoa.h>

@interface GBToolbarPopUpButtonCell : NSPopUpButtonCell

@end
