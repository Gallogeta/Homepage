#import "GBDisabledButton.h"

@implementation GBDisabledButton
- (void)mouseDown:(NSEvent *)event
{
    
}
@end
