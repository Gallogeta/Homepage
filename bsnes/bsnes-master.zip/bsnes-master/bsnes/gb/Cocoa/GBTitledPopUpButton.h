#import <Cocoa/Cocoa.h>

@interface GBTitledPopUpButton : NSPopUpButton
@property NSString *displayTitle;
@end
