#import <UIKit/UIKit.h>

@interface UIToolbar (disableCompact)
@property bool disableCompactLayout;
@end
