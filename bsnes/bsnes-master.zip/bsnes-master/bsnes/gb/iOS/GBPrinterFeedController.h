#import <UIKit/UIKit.h>

@interface GBPrinterFeedController : UINavigationController
- (instancetype)initWithImage:(UIImage *)image;
@end

