#import <UIKit/UIKit.h>

@interface UILabel (TapLocation)
- (unsigned)characterAtTap:(UITapGestureRecognizer *)tap;
@end
