#import <UIKit/UIKit.h>

@interface GBActivityViewController : UIActivityViewController

@end
