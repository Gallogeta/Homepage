#import "GBLayout.h"

@interface GBHorizontalLayout : GBLayout
- (instancetype)initWithTheme:(GBTheme *)theme cutoutOnRight:(bool)cutoutOnRight;
@end
