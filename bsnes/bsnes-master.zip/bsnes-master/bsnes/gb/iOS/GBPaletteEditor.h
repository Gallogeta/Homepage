#import <UIKit/UIKit.h>

API_AVAILABLE(ios(14.0))
@interface GBPaletteEditor : UITableViewController 
- (instancetype)initForPalette:(NSString *)name;
@end

