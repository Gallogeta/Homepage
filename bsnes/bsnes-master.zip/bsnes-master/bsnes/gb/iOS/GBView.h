#import "GBViewBase.h"

@interface GBView : GBViewBase

@end
