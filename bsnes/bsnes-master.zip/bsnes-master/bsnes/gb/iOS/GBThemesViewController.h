#import <UIKit/UIKit.h>
#import "GBTheme.h"

@interface GBThemesViewController : UITableViewController
+ (NSArray<NSArray<GBTheme *> *> *)themes;
@end

