#import "GBLayout.h"

@interface GBVerticalLayout : GBLayout

@end
