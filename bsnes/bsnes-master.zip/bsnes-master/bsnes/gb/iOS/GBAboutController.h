#import <UIKit/UIKit.h>

@interface GBAboutController : UIViewController

@end
