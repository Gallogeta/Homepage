#import <UIKit/UIKit.h>
#import "GBTheme.h"

@interface GBThemePreviewController : UIViewController
- (instancetype)initWithTheme:(GBTheme *)theme;
@end

