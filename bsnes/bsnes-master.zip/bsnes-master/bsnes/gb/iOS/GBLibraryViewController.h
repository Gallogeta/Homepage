#import <UIKit/UIKit.h>

@interface GBLibraryViewController : UITabBarController
@end


