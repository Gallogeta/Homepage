#import <UIKit/UIKit.h>
#import <Core/gb.h>

@interface GBCheatsController : UITableViewController
- (instancetype)initWithGameBoy:(GB_gameboy_t *)gb;
@end

