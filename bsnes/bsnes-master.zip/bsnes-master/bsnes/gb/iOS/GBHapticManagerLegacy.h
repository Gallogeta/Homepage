#import "GBHapticManager.h"

@interface GBHapticManagerLegacy : GBHapticManager

@end
