#import <UIKit/UIKit.h>

API_AVAILABLE(ios(14.0))
@interface GBColorWell : UIColorWell

@end

