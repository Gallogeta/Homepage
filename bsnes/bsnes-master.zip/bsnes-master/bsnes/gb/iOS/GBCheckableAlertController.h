#import <UIKit/UIKit.h>

@interface GBCheckableAlertController : UIAlertController
@property UIAlertAction *selectedAction;
@end
