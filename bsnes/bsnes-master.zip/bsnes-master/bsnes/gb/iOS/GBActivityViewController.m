#import "GBActivityViewController.h"

@implementation GBActivityViewController

- (UIModalPresentationStyle)modalPresentationStyle
{
    return UIModalPresentationFormSheet;
}

@end
