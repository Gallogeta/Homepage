#import <UIKit/UIKit.h>

@interface GBMenuButton : UIButton

@end
