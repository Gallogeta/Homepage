bsnes was originally developed by byuu, and is now a group project.

This software would not be where it is today without the help and support of the following individuals:

  - Andreas Naive
  - Ange Albertini
  - anomie
  - AWJ
  - BearOso
  - Bisqwit
  - blargg
  - byuu
  - Łukasz Krawczyk
  - Danish
  - DerKoun
  - DMV27
  - Dr. Decapitator
  - endrift
  - Fatbag
  - FitzRoy
  - gekkio
  - GIGO
  - Hendricks266
  - hex_usr
  - ikari_01
  - jchadwick
  - Jonas Quinn
  - kode54
  - krom
  - Lioncash
  - Lord Nightmare
  - lowkey
  - Matthew Callis
  - Max833
  - MerryMage
  - mightymo
  - Nach
  - ncbncb
  - neviksti
  - OV2
  - Overload
  - p4plus2
  - quequotion
  - qwertymodo
  - RedDwarf
  - Richard Bannister
  - Ryphecha
  - segher
  - Sintendo
  - SuperMikeMan
  - Talarubi
  - tetsuo55
  - TmEE
  - TRAC
  - wareya
  - zones

If you feel you are missing from this list, please submit a pull request and we will be happy to add your name here!

